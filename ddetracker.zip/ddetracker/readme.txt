for use SDRSharpDriverDDE
unpack file to sdrsharp directory
add to Orbitron setup.cfg:

[Drivers]
SDRSharp = SDRSharpDriverDDE.exe
